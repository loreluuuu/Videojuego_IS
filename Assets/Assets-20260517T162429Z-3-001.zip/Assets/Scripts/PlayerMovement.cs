using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public float speed = 5f;
    public float jumpForce = 7f;

    private Rigidbody2D rb;
    private Animator animator;

    private bool isGrounded;

    // DOBLE SALTO
    private int jumpCount;
    public int maxJumps = 2;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
    }

    void Update()
    {
        float move = Input.GetAxisRaw("Horizontal");

        // Movimiento
        rb.linearVelocity = new Vector2(move * speed, rb.linearVelocity.y);

        // Animación caminar
        animator.SetBool("isWalking", move != 0);

        // Voltear personaje
        if (move > 0)
        {
            transform.localScale = new Vector3(2.3f, 1.7f, 1);
        }
        else if (move < 0)
        {
            transform.localScale = new Vector3(-2.3f, 1.7f, 1);
        }

        // DOBLE SALTO
        if (Input.GetKeyDown(KeyCode.Space) && jumpCount < maxJumps)
        {
            rb.linearVelocity = new Vector2(rb.linearVelocity.x, jumpForce);

            jumpCount++;
        }

        // ATAQUE
        if (Input.GetMouseButtonDown(0))
        {
            animator.SetTrigger("Attack");
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Ground"))
        {
            isGrounded = true;

            // Reiniciar saltos
            jumpCount = 0;
        }
    }

    private void OnCollisionExit2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Ground"))
        {
            isGrounded = false;
        }
    }
}